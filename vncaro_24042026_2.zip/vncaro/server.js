require('dotenv').config();
const express  = require('express');
const http     = require('http');
const { Server } = require('socket.io');
const path     = require('path');
const cors     = require('cors');

const { initDB }            = require('./src/db');
const authRoutes            = require('./src/routes/auth');
const leaderboardRoutes     = require('./src/routes/leaderboard');
const { verifySocketToken } = require('./src/middleware/auth');
const { setupHandlers, initMatchmaking } = require('./src/handlers');

// ─── App setup ────────────────────────────────────────────────────────────────

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── API routes ───────────────────────────────────────────────────────────────

app.use('/api/auth',        authRoutes);
app.use('/api/leaderboard', leaderboardRoutes);

// SPA fallback
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Database ─────────────────────────────────────────────────────────────────

initDB();

// ─── Socket.io ────────────────────────────────────────────────────────────────

io.use(verifySocketToken);

io.on('connection', (socket) => {
  console.log(`✅ Connected: ${socket.user.username} (${socket.id})`);
  setupHandlers(io, socket);

  // Broadcast online count on connect/disconnect
  const broadcastCount = () => {
    io.emit('online_count', { count: io.sockets.sockets.size });
  };
  broadcastCount();
  socket.on('disconnect', () => {
    console.log(`❌ Disconnected: ${socket.user.username}`);
    broadcastCount();
  });
});

initMatchmaking(io);

// ─── Start ────────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🎮  VNCaro đang chạy tại http://localhost:${PORT}\n`);
});
