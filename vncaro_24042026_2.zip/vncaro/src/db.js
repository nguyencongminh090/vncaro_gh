'use strict';
const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'vncaro.db');
let db;

function getDB() {
  if (!db) {
    db = new DatabaseSync(DB_PATH);
    db.exec('PRAGMA journal_mode = WAL');
    db.exec('PRAGMA foreign_keys = ON');
  }
  return db;
}

function initDB() {
  const d = getDB();
  d.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      elo INTEGER DEFAULT 1000,
      wins INTEGER DEFAULT 0,
      losses INTEGER DEFAULT 0,
      draws INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS games (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_code TEXT,
      player1_id INTEGER NOT NULL,
      player2_id INTEGER NOT NULL,
      winner_id INTEGER,
      draw INTEGER DEFAULT 0,
      p1_elo_before INTEGER, p2_elo_before INTEGER,
      p1_elo_after INTEGER, p2_elo_after INTEGER,
      total_moves INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_users_elo ON users(elo DESC);
  `);
  console.log('Database khởi tạo thành công');
}

function createUser(username, passwordHash) {
  const r = getDB().prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username, passwordHash);
  return r.lastInsertRowid;
}
function findUserByUsername(username) { return getDB().prepare('SELECT * FROM users WHERE username = ?').get(username); }
function findUserById(id) { return getDB().prepare('SELECT * FROM users WHERE id = ?').get(id); }
function updateUserStats(userId, { eloDelta, result }) {
  let w=0,l=0,dr=0;
  if(result==='win') w=1; else if(result==='loss') l=1; else dr=1;
  getDB().prepare('UPDATE users SET elo=MAX(100,elo+?),wins=wins+?,losses=losses+?,draws=draws+? WHERE id=?').run(eloDelta,w,l,dr,userId);
}
function getLeaderboard(limit=50) {
  return getDB().prepare('SELECT id,username,elo,wins,losses,draws,(wins+losses+draws) AS total_games FROM users ORDER BY elo DESC,wins DESC LIMIT ?').all(limit);
}
function getUserRank(userId) {
  const d=getDB();
  const user=d.prepare('SELECT id,username,elo,wins,losses,draws,(wins+losses+draws) AS total_games FROM users WHERE id=?').get(userId);
  if(!user) return null;
  const {rank}=d.prepare('SELECT COUNT(*) AS rank FROM users WHERE elo>?').get(user.elo);
  return {...user,rank:rank+1};
}
function saveGame({roomCode,player1Id,player2Id,winnerId,draw,p1EloBefore,p2EloBefore,p1EloAfter,p2EloAfter,totalMoves}) {
  getDB().prepare('INSERT INTO games(room_code,player1_id,player2_id,winner_id,draw,p1_elo_before,p2_elo_before,p1_elo_after,p2_elo_after,total_moves) VALUES(?,?,?,?,?,?,?,?,?,?)').run(roomCode,player1Id,player2Id,winnerId??null,draw?1:0,p1EloBefore,p2EloBefore,p1EloAfter,p2EloAfter,totalMoves);
}
function calcELO(winnerElo,loserElo,K=32) {
  const e=1/(1+Math.pow(10,(loserElo-winnerElo)/400));
  return {winnerDelta:Math.round(K*(1-e)),loserDelta:Math.round(K*(0-(1-e)))};
}
function calcELODraw(elo1,elo2,K=32) {
  const e1=1/(1+Math.pow(10,(elo2-elo1)/400));
  const d1=Math.round(K*(0.5-e1));
  return {delta1:d1,delta2:-d1};
}

module.exports = {initDB,getDB,createUser,findUserByUsername,findUserById,updateUserStats,getLeaderboard,getUserRank,saveGame,calcELO,calcELODraw};
