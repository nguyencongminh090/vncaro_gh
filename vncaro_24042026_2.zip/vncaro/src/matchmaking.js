// ─── Matchmaking Queue ────────────────────────────────────────────────────────
// Each entry: { socketId, userId, username, elo, joinedAt }
const queue = [];
const inQueue = new Set(); // userId set

const ELO_RANGE_START  = 200;
const ELO_RANGE_EXPAND = 100; // expand every 15s
const MAX_ELO_RANGE    = 800;
const TICK_MS          = 3000;

let ticker = null;

function joinQueue(player) {
  if (inQueue.has(player.userId)) return false;
  queue.push({ ...player, joinedAt: Date.now() });
  inQueue.add(player.userId);
  return true;
}

function leaveQueue(userId) {
  const idx = queue.findIndex(p => p.userId === userId);
  if (idx !== -1) queue.splice(idx, 1);
  inQueue.delete(userId);
}

function isInQueue(userId) { return inQueue.has(userId); }

// Return best match for player at index i, or null
function findMatch(i) {
  const p = queue[i];
  const waitSec = (Date.now() - p.joinedAt) / 1000;
  const range = Math.min(
    ELO_RANGE_START + Math.floor(waitSec / 15) * ELO_RANGE_EXPAND,
    MAX_ELO_RANGE
  );

  let bestIdx = -1;
  let bestDiff = Infinity;

  for (let j = 0; j < queue.length; j++) {
    if (j === i) continue;
    const diff = Math.abs(queue[j].elo - p.elo);
    if (diff <= range && diff < bestDiff) {
      bestDiff = diff;
      bestIdx = j;
    }
  }
  return bestIdx;
}

// Called with io to emit events when match found
function startTicker(io, onMatch) {
  if (ticker) return;
  ticker = setInterval(() => {
    const matched = new Set();
    for (let i = 0; i < queue.length; i++) {
      if (matched.has(i)) continue;
      const j = findMatch(i);
      if (j !== -1 && !matched.has(j)) {
        matched.add(i);
        matched.add(j);
        const p1 = queue[i];
        const p2 = queue[j];
        onMatch(p1, p2);
      }
    }
    // Remove matched players (reverse order to keep indices valid)
    Array.from(matched).sort((a,b) => b-a).forEach(idx => queue.splice(idx, 1));
    matched.forEach((idx) => {}); // cleanup handled above
    // Clean up inQueue
    queue.forEach(p => {}); // inQueue stays until leaveQueue is explicitly called
  }, TICK_MS);
}

function stopTicker() {
  if (ticker) { clearInterval(ticker); ticker = null; }
}

module.exports = { joinQueue, leaveQueue, isInQueue, startTicker, stopTicker };
