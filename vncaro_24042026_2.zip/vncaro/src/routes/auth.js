'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const { createUser, findUserByUsername, findUserById, getUserRank } = require('../db');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

function validateUsername(u) {
  if (!u || u.length < 3 || u.length > 20) return 'Tên 3–20 ký tự';
  if (!/^[a-zA-Z0-9_]+$/.test(u)) return 'Chỉ dùng chữ, số, dấu gạch dưới';
  return null;
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const uErr = validateUsername(username);
    if (uErr) return res.status(400).json({ error: uErr });
    if (!password || password.length < 6) return res.status(400).json({ error: 'Mật khẩu tối thiểu 6 ký tự' });
    if (findUserByUsername(username)) return res.status(409).json({ error: 'Tên đăng nhập đã tồn tại' });
    const hash = await bcrypt.hash(password, 10);
    const id = createUser(username, hash);
    const token = signToken({ id, username });
    res.json({ token, user: { id, username, elo: 1200, wins: 0, losses: 0, draws: 0 } });
  } catch(e) { res.status(500).json({ error: 'Lỗi máy chủ' }); }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Vui lòng nhập đầy đủ' });
    const user = findUserByUsername(username);
    if (!user) return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu' });
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu' });
    const token = signToken({ id: user.id, username: user.username });
    res.json({ token, user: { id: user.id, username: user.username, elo: user.elo, wins: user.wins, losses: user.losses, draws: user.draws } });
  } catch(e) { res.status(500).json({ error: 'Lỗi máy chủ' }); }
});

// POST /api/auth/google  — verify Google ID token
router.post('/google', async (req, res) => {
  try {
    const { credential } = req.body;
    if (!credential) return res.status(400).json({ error: 'Thiếu credential' });

    const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
    if (!GOOGLE_CLIENT_ID) return res.status(503).json({ error: 'Google OAuth chưa được cấu hình' });

    // Decode JWT payload (Google ID token is a JWT)
    const parts = credential.split('.');
    if (parts.length !== 3) return res.status(400).json({ error: 'Credential không hợp lệ' });
    const payload = JSON.parse(Buffer.from(parts[1].replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString());

    if (payload.aud !== GOOGLE_CLIENT_ID) return res.status(401).json({ error: 'Client ID không khớp' });
    if (payload.exp < Date.now()/1000) return res.status(401).json({ error: 'Token đã hết hạn' });

    const googleId = payload.sub;
    const displayName = (payload.name || payload.email.split('@')[0]).replace(/[^a-zA-Z0-9_]/g, '_').substring(0, 18);

    // Find by google_id or create
    let user = findUserByUsername('g_' + googleId.substring(0,12));
    if (!user) {
      // Check if display name taken, add suffix if needed
      let uname = displayName;
      if (findUserByUsername(uname)) uname = uname.substring(0,15) + '_' + Math.floor(Math.random()*999);
      const id = createUser(uname, 'GOOGLE_AUTH_' + googleId);
      user = findUserById(id);
    }

    const token = signToken({ id: user.id, username: user.username });
    res.json({ token, user: { id: user.id, username: user.username, elo: user.elo, wins: user.wins, losses: user.losses, draws: user.draws } });
  } catch(e) {
    console.error('Google auth error:', e);
    res.status(500).json({ error: 'Lỗi xác thực Google' });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  try {
    const info = getUserRank(req.user.id);
    if (!info) return res.status(404).json({ error: 'Không tìm thấy' });
    res.json({ user: info });
  } catch(e) { res.status(500).json({ error: 'Lỗi máy chủ' }); }
});

module.exports = router;
