const express = require('express');
const { getLeaderboard, getUserRank } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/leaderboard
router.get('/', (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 50, 100);
    const board = getLeaderboard(limit);
    res.json({ leaderboard: board });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi máy chủ' });
  }
});

// GET /api/leaderboard/me
router.get('/me', requireAuth, (req, res) => {
  try {
    const info = getUserRank(req.user.id);
    res.json({ rank: info });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi máy chủ' });
  }
});

module.exports = router;
