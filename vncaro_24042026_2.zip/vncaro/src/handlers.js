'use strict';
const {
  games, waitingRooms,
  createGame, getGame, deleteGame,
  isForbidden, checkWinner, checkDraw,
  generateRoomCode, MOVE_TIME, BOARD_SIZE
} = require('./game');
const { findUserById, updateUserStats, saveGame, calcELO, calcELODraw } = require('./db');
const { joinQueue, leaveQueue, startTicker } = require('./matchmaking');

function setupHandlers(io, socket) {
  const { id: userId, username } = socket.user;
  socket.currentRoom = null;

  function freshElo() {
    const u = findUserById(userId);
    return u ? u.elo : 1200;
  }

  function startMoveTimer(roomCode) {
    const game = getGame(roomCode);
    if (!game) return;
    if (game.timer) clearInterval(game.timer);
    game.timeLeft = MOVE_TIME;
    io.to(roomCode).emit('timer', { timeLeft: game.timeLeft });
    game.timer = setInterval(() => {
      game.timeLeft--;
      io.to(roomCode).emit('timer', { timeLeft: game.timeLeft });
      if (game.timeLeft <= 0) {
        clearInterval(game.timer); game.timer = null;
        endGame(roomCode, game.currentTurn === 'X' ? 'O' : 'X', 'timeout');
      }
    }, 1000);
  }

  function endGame(roomCode, winnerPiece, reason) {
    const game = getGame(roomCode);
    if (!game || game.status !== 'playing') return;
    game.status = 'finished';
    if (game.timer) { clearInterval(game.timer); game.timer = null; }
    const isDraw = winnerPiece === null;
    const p = game.players;
    const elo1B = findUserById(p.X.userId)?.elo ?? p.X.elo;
    const elo2B = findUserById(p.O.userId)?.elo ?? p.O.elo;
    let xDelta = 0, oDelta = 0;
    if (isDraw) {
      const { delta1, delta2 } = calcELODraw(elo1B, elo2B);
      xDelta = delta1; oDelta = delta2;
      updateUserStats(p.X.userId, { eloDelta: delta1, result: 'draw' });
      updateUserStats(p.O.userId, { eloDelta: delta2, result: 'draw' });
    } else {
      const isXWin = winnerPiece === 'X';
      const { winnerDelta, loserDelta } = calcELO(isXWin ? elo1B : elo2B, isXWin ? elo2B : elo1B);
      xDelta = isXWin ? winnerDelta : loserDelta;
      oDelta = isXWin ? loserDelta : winnerDelta;
      updateUserStats(p.X.userId, { eloDelta: xDelta, result: isXWin ? 'win' : 'loss' });
      updateUserStats(p.O.userId, { eloDelta: oDelta, result: isXWin ? 'loss' : 'win' });
    }
    saveGame({
      roomCode, player1Id: p.X.userId, player2Id: p.O.userId,
      winnerId: isDraw ? null : (winnerPiece === 'X' ? p.X.userId : p.O.userId),
      draw: isDraw,
      p1EloBefore: elo1B, p2EloBefore: elo2B,
      p1EloAfter: elo1B + xDelta, p2EloAfter: elo2B + oDelta,
      totalMoves: game.moveCount
    });
    io.to(roomCode).emit('game_over', {
      reason, draw: isDraw,
      winner: isDraw ? null : (winnerPiece === 'X' ?
        { userId: p.X.userId, username: p.X.username } :
        { userId: p.O.userId, username: p.O.username }),
      eloChanges: {
        [p.X.userId]: { delta: xDelta, newElo: elo1B + xDelta },
        [p.O.userId]: { delta: oDelta, newElo: elo2B + oDelta }
      }
    });
    deleteGame(roomCode);
  }

  function startGameInRoom(roomCode, playerX, playerO) {
    const game = createGame(roomCode, playerX, playerO);
    waitingRooms.delete(roomCode);
    io.to(roomCode).emit('game_start', {
      roomCode,
      board: game.board,
      forbidden: game.forbidden,
      players: {
        X: { userId: playerX.userId, username: playerX.username, elo: playerX.elo },
        O: { userId: playerO.userId, username: playerO.username, elo: playerO.elo }
      },
      currentTurn: 'X'
    });
    startMoveTimer(roomCode);
  }

  function leaveCurrentRoom() {
    const room = socket.currentRoom;
    if (!room) return;
    if (waitingRooms.has(room)) waitingRooms.delete(room);
    const game = getGame(room);
    if (game && game.status === 'playing') {
      const leftPiece = game.players.X.socketId === socket.id ? 'X' : 'O';
      endGame(room, leftPiece === 'X' ? 'O' : 'X', 'disconnect');
    }
    socket.leave(room);
    socket.currentRoom = null;
  }

  socket.on('create_room', () => {
    try {
      leaveCurrentRoom();
      const code = generateRoomCode();
      waitingRooms.set(code, {
        code, host: { socketId: socket.id, userId, username, elo: freshElo() }
      });
      socket.join(code);
      socket.currentRoom = code;
      socket.emit('room_created', { roomCode: code });
    } catch(e) { socket.emit('room_error', { message: 'Không thể tạo phòng' }); }
  });

  socket.on('join_room', ({ roomCode }) => {
    try {
      const code = (roomCode || '').toUpperCase().trim();
      const waiting = waitingRooms.get(code);
      if (!waiting) return socket.emit('room_error', { message: 'Mã phòng không tồn tại' });
      if (waiting.host.userId === userId) return socket.emit('room_error', { message: 'Không thể tự vào phòng của mình' });
      leaveCurrentRoom();
      const elo = freshElo();
      socket.join(code);
      socket.currentRoom = code;
      const coinFlip = Math.random() < 0.5;
      const playerX = coinFlip ? waiting.host : { socketId: socket.id, userId, username, elo };
      const playerO = coinFlip ? { socketId: socket.id, userId, username, elo } : waiting.host;
      startGameInRoom(code, playerX, playerO);
    } catch(e) { socket.emit('room_error', { message: 'Lỗi khi vào phòng' }); }
  });

  socket.on('join_matchmaking', () => {
    leaveCurrentRoom();
    const joined = joinQueue({ socketId: socket.id, userId, username, elo: freshElo() });
    if (joined) socket.emit('matchmaking_status', { status: 'searching' });
  });

  socket.on('cancel_matchmaking', () => {
    leaveQueue(userId);
    socket.emit('matchmaking_status', { status: 'cancelled' });
  });

  socket.on('make_move', ({ roomCode, row, col }) => {
    try {
      const game = getGame(roomCode);
      if (!game || game.status !== 'playing') return;
      const piece = game.players.X.socketId === socket.id ? 'X' : 'O';
      if (piece !== game.currentTurn) return;
      if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return;
      if (game.board[row][col] !== null) return;
      if (isForbidden(game, row, col)) return;
      game.board[row][col] = piece;
      if (piece === 'X' && game.moveCount === 0) game.xFirst = [row, col];
      game.moveCount++;
      game.currentTurn = piece === 'X' ? 'O' : 'X';
      const winCells = checkWinner(game.board, row, col, piece);
      if (winCells) {
        io.to(roomCode).emit('move_made', { row, col, piece, nextTurn: game.currentTurn, moveCount: game.moveCount, winCells });
        endGame(roomCode, piece, 'win');
      } else if (checkDraw(game.board)) {
        io.to(roomCode).emit('move_made', { row, col, piece, nextTurn: game.currentTurn, moveCount: game.moveCount });
        endGame(roomCode, null, 'draw');
      } else {
        io.to(roomCode).emit('move_made', { row, col, piece, nextTurn: game.currentTurn, moveCount: game.moveCount });
        startMoveTimer(roomCode);
      }
    } catch(e) { console.error('make_move error:', e); }
  });

  socket.on('resign', ({ roomCode }) => {
    const game = getGame(roomCode);
    if (!game || game.status !== 'playing') return;
    const resignerPiece = game.players.X.socketId === socket.id ? 'X' : 'O';
    endGame(roomCode, resignerPiece === 'X' ? 'O' : 'X', 'resign');
  });

  socket.on('leave_room', leaveCurrentRoom);

  socket.on('disconnect', () => {
    leaveQueue(userId);
    leaveCurrentRoom();
  });

  socket.on('get_online_count', () => {
    socket.emit('online_count', { count: io.sockets.sockets.size });
  });
}

function initMatchmaking(io) {
  startTicker(io, (p1, p2) => {
    const { leaveQueue } = require('./matchmaking');
    leaveQueue(p1.userId); leaveQueue(p2.userId);
    const u1 = findUserById(p1.userId), u2 = findUserById(p2.userId);
    p1.elo = u1?.elo ?? p1.elo; p2.elo = u2?.elo ?? p2.elo;
    const code = generateRoomCode();
    const s1 = io.sockets.sockets.get(p1.socketId);
    const s2 = io.sockets.sockets.get(p2.socketId);
    if (!s1 || !s2) return;
    s1.join(code); s1.currentRoom = code;
    s2.join(code); s2.currentRoom = code;
    const coinFlip = Math.random() < 0.5;
    const playerX = coinFlip ? p1 : p2;
    const playerO = coinFlip ? p2 : p1;
    const game = createGame(code, playerX, playerO);
    io.to(code).emit('matched', { roomCode: code });
    io.to(code).emit('game_start', {
      roomCode: code, board: game.board, forbidden: game.forbidden,
      players: {
        X: { userId: playerX.userId, username: playerX.username, elo: playerX.elo },
        O: { userId: playerO.userId, username: playerO.username, elo: playerO.elo }
      },
      currentTurn: 'X'
    });
    // Start timer
    game.timeLeft = MOVE_TIME;
    io.to(code).emit('timer', { timeLeft: MOVE_TIME });
    game.timer = setInterval(() => {
      game.timeLeft--;
      io.to(code).emit('timer', { timeLeft: game.timeLeft });
      if (game.timeLeft <= 0) {
        clearInterval(game.timer); game.timer = null;
        // handled by endGame below via timeout
        const g = getGame(code);
        if (g && g.status === 'playing') {
          const loserPiece = g.currentTurn;
          // call endGame via a fake socket event isn't ideal, replicate inline
          g.status = 'finished';
          const winner = loserPiece === 'X' ? 'O' : 'X';
          const elo1B = findUserById(p1.userId)?.elo ?? p1.elo;
          const elo2B = findUserById(p2.userId)?.elo ?? p2.elo;
          const isXWin = winner === 'X';
          const { winnerDelta, loserDelta } = require('./db').calcELO(isXWin ? elo1B : elo2B, isXWin ? elo2B : elo1B);
          const xD = isXWin ? winnerDelta : loserDelta;
          const oD = isXWin ? loserDelta : winnerDelta;
          updateUserStats(playerX.userId, { eloDelta: xD, result: isXWin ? 'win' : 'loss' });
          updateUserStats(playerO.userId, { eloDelta: oD, result: isXWin ? 'loss' : 'win' });
          saveGame({ roomCode: code, player1Id: playerX.userId, player2Id: playerO.userId,
            winnerId: isXWin ? playerX.userId : playerO.userId, draw: false,
            p1EloBefore: elo1B, p2EloBefore: elo2B, p1EloAfter: elo1B+xD, p2EloAfter: elo2B+oD, totalMoves: g.moveCount });
          io.to(code).emit('game_over', {
            reason: 'timeout', draw: false,
            winner: { userId: isXWin ? playerX.userId : playerO.userId, username: isXWin ? playerX.username : playerO.username },
            eloChanges: { [playerX.userId]: { delta: xD, newElo: elo1B+xD }, [playerO.userId]: { delta: oD, newElo: elo2B+oD } }
          });
          deleteGame(code);
        }
      }
    }, 1000);
    io.to(code).emit('online_count', { count: io.sockets.sockets.size });
  });
}

module.exports = { setupHandlers, initMatchmaking };
