'use strict';
const BOARD_SIZE = 19;
const WIN_LENGTH = 5;
const MOVE_TIME  = 60;

const games = new Map();
const waitingRooms = new Map();

function createEmptyBoard() {
  return Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
}

// Generate 3 forbidden cells on perimeter of square A (rows5-12, cols5-13, 0-indexed)
// Perimeter has 30 cells, pick 3 at indices 0,10,20 (≥7 apart)
function genForbidden() {
  const perim = [];
  for (let c = 5; c <= 13; c++) perim.push([5, c]);   // top
  for (let r = 6; r <= 12; r++) perim.push([r, 13]);  // right
  for (let c = 12; c >= 5; c--) perim.push([12, c]);  // bottom
  for (let r = 11; r >= 6; r--) perim.push([r, 5]);   // left
  // pick 3 random indices spaced >=7 apart
  const n = perim.length; // 30
  const i1 = Math.floor(Math.random() * n);
  const i2 = (i1 + 10 + Math.floor(Math.random() * 4)) % n;
  const i3 = (i1 + 20 + Math.floor(Math.random() * 4)) % n;
  return [perim[i1], perim[i2], perim[i3]];
}

function createGame(roomCode, playerX, playerO) {
  const state = {
    roomCode,
    board: createEmptyBoard(),
    forbidden: genForbidden(),
    players: { X: playerX, O: playerO },
    currentTurn: 'X',
    status: 'playing',
    moveCount: 0,
    xFirst: null,
    timer: null,
    timeLeft: MOVE_TIME,
  };
  games.set(roomCode, state);
  return state;
}

function getGame(roomCode) { return games.get(roomCode); }

function deleteGame(roomCode) {
  const g = games.get(roomCode);
  if (g?.timer) clearInterval(g.timer);
  games.delete(roomCode);
}

function isForbidden(game, row, col) {
  return game.forbidden.some(([r,c]) => r === row && c === col);
}

function checkWinner(board, row, col, piece) {
  const dirs = [[0,1],[1,0],[1,1],[1,-1]];
  for (const [dr, dc] of dirs) {
    const cells = [[row, col]];
    for (let i = 1; i < 5; i++) {
      const r = row + dr*i, c = col + dc*i;
      if (r<0||r>=BOARD_SIZE||c<0||c>=BOARD_SIZE||board[r][c]!==piece) break;
      cells.push([r,c]);
    }
    for (let i = 1; i < 5; i++) {
      const r = row - dr*i, c = col - dc*i;
      if (r<0||r>=BOARD_SIZE||c<0||c>=BOARD_SIZE||board[r][c]!==piece) break;
      cells.push([r,c]);
    }
    if (cells.length >= WIN_LENGTH) return cells;
  }
  return null;
}

function checkDraw(board) {
  return board.every(row => row.every(cell => cell !== null));
}

function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 6 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join('');
  } while (waitingRooms.has(code) || games.has(code));
  return code;
}

module.exports = {
  games, waitingRooms,
  createGame, getGame, deleteGame,
  isForbidden, checkWinner, checkDraw,
  generateRoomCode, MOVE_TIME, BOARD_SIZE
};
