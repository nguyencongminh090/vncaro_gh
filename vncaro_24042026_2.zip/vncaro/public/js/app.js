'use strict';
// ── STATE ──────────────────────────────────────────────────────────────────
var socket = null;
var currentUser = null;
var currentRoom = null;
var chatOn = true;
var wtTimer = null;

// Board state (client-side display)
var BD = []; // 19x19, null/'X'/'O'
var FORB = []; // [[r,c],...] 0-indexed
var turn = 'X', moveCount = 0;
var xFirst = null, oFirst = null;
var selCell = null;
var gameOver = false, winCells = [];
var timeLeft = 60;
var bOp = 0.10, nOp = 0.50;
var myPiece = null; // 'X' or 'O'
var pinchScale = 1, pinchStart = 1;

// ── TOAST ──────────────────────────────────────────────────────────────────
function toast(msg, type) {
  var t = document.createElement('div');
  t.className = 'toast toast-' + (type||'i');
  t.textContent = msg;
  document.getElementById('toast-wrap').appendChild(t);
  setTimeout(function(){ if(t.parentNode) t.parentNode.removeChild(t); }, 3000);
}

// ── SCREENS ────────────────────────────────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(function(s){ s.classList.remove('active'); });
  document.getElementById(id).classList.add('active');
}

// ── AUTH ───────────────────────────────────────────────────────────────────
function authTab(tab) {
  document.querySelectorAll('.at').forEach(function(b){ b.classList.remove('active'); });
  document.querySelectorAll('.auth-form').forEach(function(f){ f.classList.remove('active'); });
  document.querySelector('.at[onclick*="'+tab+'"]').classList.add('active');
  document.getElementById('f-'+tab).classList.add('active');
}

async function doLogin(e) {
  e.preventDefault();
  var u = document.getElementById('l-user').value.trim();
  var p = document.getElementById('l-pass').value;
  var err = document.getElementById('l-err');
  err.textContent = '';
  try {
    var data = await API.login(u, p);
    afterAuth(data);
  } catch(ex) { err.textContent = ex.message; }
}

async function doRegister(e) {
  e.preventDefault();
  var u = document.getElementById('r-user').value.trim();
  var p = document.getElementById('r-pass').value;
  var c = document.getElementById('r-conf').value;
  var err = document.getElementById('r-err');
  err.textContent = '';
  if (p !== c) { err.textContent = 'Mật khẩu xác nhận không khớp'; return; }
  try {
    var data = await API.register(u, p);
    afterAuth(data);
  } catch(ex) { err.textContent = ex.message; }
}

// Google login
function triggerGoogle() {
  // Check if Google GSI is available
  if (window.google && window.google.accounts) {
    google.accounts.id.prompt();
  } else {
    toast('Google đăng nhập chưa được cấu hình. Vui lòng dùng tài khoản thủ công.', 'e');
  }
}

async function onGoogleLogin(response) {
  try {
    var data = await API.loginGoogle(response.credential);
    afterAuth(data);
  } catch(ex) { toast('Đăng nhập Google thất bại: ' + ex.message, 'e'); }
}

function afterAuth(data) {
  API.setToken(data.token);
  currentUser = data.user;
  connectSocket(data.token);
}

function doLogout() {
  if (socket) { socket.disconnect(); socket = null; }
  API.setToken(null);
  currentUser = null;
  currentRoom = null;
  document.getElementById('pp').style.display = 'none';
  showScreen('s-login');
  navTab('home');
}

function togglePP() {
  var p = document.getElementById('pp');
  p.style.display = p.style.display === 'none' ? 'block' : 'none';
  if (p.style.display === 'block') updatePPData();
}

function updatePPData() {
  if (!currentUser) return;
  var initials = currentUser.username.substring(0,2).toUpperCase();
  document.getElementById('pp-av').textContent = initials;
  document.getElementById('hdr-av-txt').textContent = initials;
  document.getElementById('pp-name').textContent = currentUser.username;
  document.getElementById('pp-elo').textContent = 'ELO ' + currentUser.elo;
  document.getElementById('pp-stat').textContent =
    currentUser.wins + ' thắng · ' + currentUser.losses + ' thua · ' + currentUser.draws + ' hòa';
}

// ── SOCKET ─────────────────────────────────────────────────────────────────
function connectSocket(token) {
  if (socket) socket.disconnect();
  socket = io({ auth: { token } });

  socket.on('connect', function() {
    showScreen('s-app');
    updatePPData();
    updateTDTab();
    toast('Đã kết nối', 's');
  });

  socket.on('connect_error', function(err) {
    document.getElementById('l-err').textContent = err.message;
    document.getElementById('r-err').textContent = err.message;
  });

  socket.on('online_count', function(d) {
    document.getElementById('online-cnt').textContent = d.count;
  });

  socket.on('disconnect', function() {
    toast('Mất kết nối với máy chủ', 'e');
  });

  // ── ROOM EVENTS ────────────────────────────────────────────────────────────
  socket.on('room_created', function(d) {
    currentRoom = d.roomCode;
    document.getElementById('room-code-disp').textContent = d.roomCode;
    document.getElementById('gl-lobby').style.display = 'none';
    document.getElementById('gl-waiting').style.display = 'block';
    var init = currentUser ? currentUser.username.substring(0,2).toUpperCase() : '?';
    document.getElementById('glw-av').textContent = init;
    toast('Đã tạo phòng ' + d.roomCode, 's');
  });

  socket.on('room_error', function(d) {
    toast(d.message, 'e');
    document.getElementById('join-err').textContent = d.message;
  });

  socket.on('matched', function(d) {
    currentRoom = d.roomCode;
    toast('Đã tìm thấy đối thủ!', 's');
    resetMatchmakingUI();
  });

  socket.on('matchmaking_status', function(d) {
    if (d.status === 'searching') {
      document.getElementById('find-btn').style.display = 'none';
      document.getElementById('searching').style.display = 'block';
    } else {
      resetMatchmakingUI();
    }
  });

  // ── GAME EVENTS ────────────────────────────────────────────────────────────
  socket.on('game_start', function(data) {
    currentRoom = data.roomCode;
    startGame(data);
    cancelMatch(); // clean up matchmaking UI
    cancelRoom(); // clean up room waiting UI
  });

  socket.on('move_made', function(d) {
    BD[d.row][d.col] = d.piece;
    if (d.piece === 'X' && moveCount === 0) xFirst = [d.row, d.col];
    if (d.piece === 'O' && moveCount === 1) oFirst = [d.row, d.col];
    moveCount = d.moveCount;
    turn = d.nextTurn;
    selCell = null;
    if (d.winCells) winCells = d.winCells;
    renderBoard();
    updatePlayerUI();
    saveBoardState();
  });

  socket.on('timer', function(d) {
    timeLeft = d.timeLeft;
    var el = document.getElementById(turn === 'X' ? 'tx' : 'to');
    if (el) el.textContent = d.timeLeft;
    if (d.timeLeft <= 10 && d.timeLeft > 0) beep();
  });

  socket.on('game_over', function(result) {
    gameOver = true;
    sessionStorage.removeItem('vncaro_game');
    showResult(result);
    // refresh user ELO
    if (currentUser && result.eloChanges && result.eloChanges[currentUser.id]) {
      var ch = result.eloChanges[currentUser.id];
      currentUser.elo = ch.newElo;
      updateTDTab();
      updatePPData();
    }
  });
}

// ── NAV ────────────────────────────────────────────────────────────────────
function navTab(tab) {
  document.querySelectorAll('.nt').forEach(function(b){ b.classList.remove('active'); });
  document.querySelectorAll('.tab-pane').forEach(function(p){ p.classList.remove('active'); });
  var nt = document.getElementById('nt-' + tab);
  var tp = document.getElementById('tp-' + tab);
  if (nt) nt.classList.add('active');
  if (tp) tp.classList.add('active');
  document.getElementById('app-cnt').scrollTop = 0;
  if (tab === 'xephang') loadLeaderboard();
}

function updateTDTab() {
  if (!currentUser) return;
  var init = currentUser.username.substring(0,2).toUpperCase();
  var avEl = document.getElementById('my-av-td');
  if (avEl) avEl.textContent = init;
  var eloEl = document.getElementById('my-elo-td');
  if (eloEl) eloEl.textContent = currentUser.elo;
}

// ── CHAT ───────────────────────────────────────────────────────────────────
function toggleChat() {
  chatOn = !chatOn;
  document.getElementById('csw').classList.toggle('on', chatOn);
  var ca = document.getElementById('chat-area');
  if (ca) ca.style.display = chatOn ? 'block' : 'none';
}

function sendMsg() {
  var inp = document.getElementById('ci');
  if (!inp || !inp.value.trim() || !chatOn) return;
  var txt = inp.value.trim().substring(0,30);
  inp.value = '';
  var fz = document.getElementById('float-zone');
  if (!fz) return;
  var m = document.createElement('div');
  m.className = 'chat-msg';
  m.textContent = txt;
  fz.appendChild(m);
  setTimeout(function(){ if(m.parentNode) m.parentNode.removeChild(m); }, 2500);
}

// ── ROOM ───────────────────────────────────────────────────────────────────
function createRoom() {
  if (!socket) { toast('Vui lòng đăng nhập', 'e'); return; }
  socket.emit('create_room');
}

function cancelRoom() {
  if (socket && currentRoom) { socket.emit('leave_room'); currentRoom = null; }
  document.getElementById('gl-lobby').style.display = 'block';
  document.getElementById('gl-waiting').style.display = 'none';
}

function joinRoomManual() {
  var code = document.getElementById('join-code').value.trim().toUpperCase();
  document.getElementById('join-err').textContent = '';
  if (code.length !== 6) { document.getElementById('join-err').textContent = 'Mã phòng gồm 6 ký tự'; return; }
  joinRoomByCode(code);
}

function joinRoomByCode(code) {
  if (!socket) { toast('Vui lòng đăng nhập', 'e'); return; }
  socket.emit('join_room', { roomCode: code });
}

document.addEventListener('DOMContentLoaded', function() {
  var ji = document.getElementById('join-code');
  if (ji) ji.addEventListener('keydown', function(e){ if(e.key==='Enter') joinRoomManual(); });
});

// ── MATCHMAKING ────────────────────────────────────────────────────────────
function findMatch() {
  if (!socket) { toast('Vui lòng đăng nhập', 'e'); return; }
  socket.emit('join_matchmaking');
}

function cancelMatch() {
  if (socket) socket.emit('cancel_matchmaking');
  resetMatchmakingUI();
}

function resetMatchmakingUI() {
  document.getElementById('find-btn').style.display = 'block';
  document.getElementById('searching').style.display = 'none';
  document.getElementById('wt').textContent = '0';
  if (wtTimer) { clearInterval(wtTimer); wtTimer = null; }
}

// Update waiting time counter
socket && socket.on('matchmaking_status', function(d) {
  if (d.status === 'searching' && !wtTimer) {
    var s = 0;
    wtTimer = setInterval(function(){
      s++;
      var el = document.getElementById('wt');
      if(el) el.textContent = s;
    }, 1000);
  }
});

// ── GAME ───────────────────────────────────────────────────────────────────
function startGame(data) {
  // Set state
  BD = data.board; // 0-indexed from server
  FORB = data.forbidden || [];
  turn = data.currentTurn;
  moveCount = 0; xFirst = null; oFirst = null;
  selCell = null; gameOver = false; winCells = [];

  // Determine my piece
  myPiece = (data.players.X.userId === currentUser.id) ? 'X' : 'O';

  // Update player info
  document.getElementById('px-name').textContent = data.players.X.username;
  document.getElementById('px-elo').textContent = 'ELO ' + data.players.X.elo;
  document.getElementById('po-name').textContent = data.players.O.username;
  document.getElementById('po-elo').textContent = 'ELO ' + data.players.O.elo;
  document.getElementById('px-av').textContent = data.players.X.username.substring(0,2).toUpperCase();
  document.getElementById('po-av').textContent = data.players.O.username.substring(0,2).toUpperCase();
  document.getElementById('game-room-lbl').textContent = 'Phòng: ' + data.roomCode;

  buildBoard();
  renderBoard();
  updatePlayerUI();
  resetPinch();
  navTab('game');
  saveBoardState();
}

function viewGame() {
  // Spectate (demo)
  toast('Chế độ xem đang phát triển', 'i');
}

// ── BOARD BUILD ────────────────────────────────────────────────────────────
function buildBoard() {
  var el = document.getElementById('board');
  if (!el) return;
  el.innerHTML = '';
  for (var r = 0; r < 19; r++) {
    for (var c = 0; c < 19; c++) {
      var d = document.createElement('div');
      d.className = 'cell';
      d.id = 'c' + r + '_' + c;
      el.appendChild(d);
      (function(row, col) {
        d.addEventListener('click', function(){ onCellClick(row, col); });
      })(r, c);
    }
  }
  // Pinch to zoom
  setupPinch();
}

function isForbid(r, c) {
  return FORB.some(function(f){ return f[0]===r && f[1]===c; });
}

function adjToForbid(r, c) {
  return FORB.some(function(f){
    return Math.abs(f[0]-r) <= 1 && Math.abs(f[1]-c) <= 1 && !(f[0]===r && f[1]===c);
  });
}

function inRadius3(r, c) {
  if (!xFirst) return false;
  return Math.abs(r - xFirst[0]) <= 3 && Math.abs(c - xFirst[1]) <= 3;
}

function getPhase() {
  if (moveCount === 0) return 0;  // X first move
  if (moveCount === 2) return 2;  // X second (Open4)
  return 1;
}

function cellVisible(r, c) {
  if (isForbid(r, c)) return 'forb';
  if (BD[r] && BD[r][c]) return 'piece';
  var ph = getPhase();
  if (ph === 0 && !adjToForbid(r, c)) return 'hidden';
  if (ph === 2 && inRadius3(r, c)) {
    // Keep O's first move visible
    if (oFirst && oFirst[0]===r && oFirst[1]===c) return 'piece';
    return 'hidden';
  }
  return 'normal';
}

// ── BOARD RENDER ───────────────────────────────────────────────────────────
function renderBoard() {
  for (var r = 0; r < 19; r++) {
    for (var c = 0; c < 19; c++) {
      var d = document.getElementById('c' + r + '_' + c);
      if (!d) continue;
      d.className = 'cell';
      d.innerHTML = '';
      d.style.borderColor = '';

      var vs = cellVisible(r, c);

      if (vs === 'forb') {
        d.classList.add('forb');
      } else if (vs === 'hidden') {
        d.classList.add('hidden');
      } else if (vs === 'piece') {
        d.classList.add('placed');
        var isWin = winCells.some(function(w){ return w[0]===r && w[1]===c; });
        if (isWin) d.classList.add('win-hl');
        var sp = document.createElement('span');
        var piece = BD[r][c];
        sp.className = piece === 'X' ? 'piece-X' : 'piece-O';
        sp.textContent = piece;
        if (isWin) sp.style.animation = 'bounce .5s ease-in-out infinite';
        d.appendChild(sp);
      } else {
        // normal
        d.style.borderColor = 'rgba(255,255,255,' + bOp + ')';
        if (selCell && selCell[0]===r && selCell[1]===c) d.classList.add('sel');
        var num = document.createElement('span');
        num.className = 'cell-num';
        num.style.color = 'rgba(255,255,255,' + nOp + ')';
        num.textContent = r * 20 + c + 1; // formula: skip multiples of 20
        d.appendChild(num);
      }
    }
  }
}

function onCellClick(r, c) {
  if (gameOver || !socket) return;
  if (myPiece !== turn) { toast('Không phải lượt của bạn', 'i'); return; }
  var vs = cellVisible(r, c);
  if (vs !== 'normal') return;
  if (getPhase() === 2 && turn === 'X' && inRadius3(r, c)) return;

  if (selCell && selCell[0] === r && selCell[1] === c) {
    // Second click: make move
    selCell = null;
    socket.emit('make_move', { roomCode: currentRoom, row: r, col: c });
  } else {
    selCell = [r, c];
    renderBoard();
  }
}

function updatePlayerUI() {
  var isX = turn === 'X';
  var txb = document.getElementById('txb');
  var tob = document.getElementById('tob');
  if (txb) txb.className = 'timer-pill tpx' + (isX ? ' active-t' : '');
  if (tob) tob.className = 'timer-pill tpo' + (!isX ? ' active-t' : '');
  var pxi = document.getElementById('px-ico');
  var poi = document.getElementById('po-ico');
  if (pxi) pxi.style.animation = isX ? 'bounce .6s ease-in-out infinite' : 'none';
  if (poi) poi.style.animation = !isX ? 'bounce .6s ease-in-out infinite' : 'none';

  if (!gameOver) {
    var ph = getPhase();
    var myT = myPiece === turn;
    if (ph === 0) setStatus(myT ? 'Lượt của bạn: chọn ô cạnh ô trung lập (2 lần để đặt)' : 'Đang chờ đối thủ đặt nước đầu...');
    else if (ph === 2) setStatus(myT ? 'Open 4: chọn ô ngoài vùng mờ' : 'Đối thủ thực hiện Open 4...');
    else setStatus(myT ? 'Lượt của bạn — bấm 2 lần để đặt quân' : 'Đang chờ đối thủ...');
  }
}

function setStatus(msg) {
  var el = document.getElementById('gstatus');
  if (el) el.textContent = msg;
}

function doResign() {
  if (!socket || !currentRoom || gameOver) return;
  if (!confirm('Bạn có chắc muốn đầu hàng?')) return;
  socket.emit('resign', { roomCode: currentRoom });
}

function updBop(v) {
  bOp = v / 600;
  document.querySelectorAll('.cell:not(.forb):not(.hidden):not(.placed)').forEach(function(c){
    c.style.borderColor = 'rgba(255,255,255,' + bOp + ')';
  });
}

function updNop(v) {
  nOp = v / 100;
  document.querySelectorAll('.cell-num').forEach(function(n){
    n.style.color = 'rgba(255,255,255,' + nOp + ')';
  });
}

// ── PINCH ZOOM ─────────────────────────────────────────────────────────────
function setupPinch() {
  var wrap = document.getElementById('board-wrap');
  var inner = document.getElementById('board-inner');
  if (!wrap || !inner) return;
  wrap.addEventListener('touchstart', function(e){
    if (e.touches.length === 2) {
      pinchStart = pinchScale;
      var dx = e.touches[0].clientX - e.touches[1].clientX;
      var dy = e.touches[0].clientY - e.touches[1].clientY;
      initialDist = Math.sqrt(dx*dx + dy*dy);
    }
  }, { passive: true });
  wrap.addEventListener('touchmove', function(e){
    if (e.touches.length === 2) {
      e.preventDefault();
      var dx = e.touches[0].clientX - e.touches[1].clientX;
      var dy = e.touches[0].clientY - e.touches[1].clientY;
      var dist = Math.sqrt(dx*dx + dy*dy);
      var newScale = pinchStart * (dist / initialDist);
      pinchScale = Math.min(Math.max(newScale, 0.6), 3.0);
      inner.style.transform = 'scale(' + pinchScale + ')';
      inner.style.transformOrigin = 'top left';
    }
  }, { passive: false });
}

var initialDist = 0;

function resetPinch() {
  pinchScale = 1;
  var inner = document.getElementById('board-inner');
  if (inner) { inner.style.transform = 'scale(1)'; }
}

// ── RESULT ─────────────────────────────────────────────────────────────────
function showResult(result) {
  var myId = currentUser ? currentUser.id : -1;
  var icon, title, sub;
  if (result.draw) { icon='🤝'; title='Hòa!'; sub='Trận đấu kết thúc bất phân thắng bại'; }
  else if (result.winner && result.winner.userId === myId) {
    var rmap = { win:'Bạn đã thắng!', resign:'Đối thủ đầu hàng!', timeout:'Đối thủ hết giờ!', disconnect:'Đối thủ thoát trận!' };
    icon='🏆'; title='Chiến thắng!'; sub = rmap[result.reason] || '';
  } else {
    var rmap2 = { win:'Đối thủ thắng.', resign:'Bạn đã đầu hàng.', timeout:'Bạn hết giờ.', disconnect:'Bạn đã thoát.' };
    icon='💔'; title='Thất bại'; sub = rmap2[result.reason] || 'Hãy cố gắng hơn!';
  }
  document.getElementById('result-icon').textContent = icon;
  document.getElementById('result-title').textContent = title;
  document.getElementById('result-sub').textContent = sub;
  var row = document.getElementById('elo-changes');
  row.innerHTML = '';
  if (result.eloChanges) {
    Object.keys(result.eloChanges).forEach(function(uid) {
      var ch = result.eloChanges[uid];
      var name = (result.winner && result.winner.userId == uid) ? result.winner.username : '---';
      if (currentUser && uid == currentUser.id) name = currentUser.username;
      var chip = document.createElement('div');
      chip.className = 'elo-chip';
      var sign = ch.delta >= 0 ? '+' : '';
      chip.innerHTML = name + ': ' + ch.newElo + ' <span class="' + (ch.delta>=0?'delta-p':'delta-n') + '">' + sign + ch.delta + '</span>';
      row.appendChild(chip);
    });
  }
  document.getElementById('result-modal').style.display = 'flex';
}

function backLobby() {
  document.getElementById('result-modal').style.display = 'none';
  currentRoom = null;
  navTab('home');
}

function playAgain() {
  document.getElementById('result-modal').style.display = 'none';
  currentRoom = null;
  navTab('thidau');
  if (socket) {
    socket.emit('join_matchmaking');
    document.getElementById('find-btn').style.display = 'none';
    document.getElementById('searching').style.display = 'block';
  }
}

// ── LEADERBOARD ────────────────────────────────────────────────────────────
async function loadLeaderboard() {
  var tbody = document.getElementById('lb-body');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="4" class="lb-loading">Đang tải...</td></tr>';
  try {
    var res = await Promise.all([API.leaderboard(), currentUser ? API.myRank() : Promise.resolve(null)]);
    var lb = res[0].leaderboard;
    var me = res[1] ? res[1].rank : null;
    tbody.innerHTML = lb.map(function(p, i) {
      var rank = i+1;
      var med = ['🥇','🥈','🥉'];
      var rk = med[i] || '#' + rank;
      var ec = i<3 ? ['#fbbf24','#9ca3af','#cd7f32'][i] : '#4ade80';
      var isMy = currentUser && p.id === currentUser.id;
      return '<tr style="' + (isMy?'background:#1a3a2a22;':'') + '">' +
        '<td style="font-weight:700;">' + rk + '</td>' +
        '<td style="color:#ddd;font-weight:600;">' + escHtml(p.username) + (isMy?' <em style="color:#4ade80;font-size:9px;">(bạn)</em>':'') + '</td>' +
        '<td style="text-align:right;color:' + ec + ';font-weight:700;">' + p.elo + '</td>' +
        '<td style="text-align:right;color:#555;">' + p.wins + '/' + p.losses + '/' + p.draws + '</td></tr>';
    }).join('');
    // My rank banner
    if (me) {
      var banner = document.getElementById('my-rank-banner');
      banner.style.display = 'flex';
      banner.innerHTML = '<div class="av av-g sz30">' + me.username.substring(0,2).toUpperCase() + '</div>' +
        '<div><div style="font-size:12px;font-weight:700;color:#eee;">Hạng #' + me.rank + '</div>' +
        '<div style="font-size:10px;color:#888;">ELO ' + me.elo + ' · ' + me.wins + 'W ' + me.losses + 'L ' + me.draws + 'D</div></div>';
    }
  } catch(ex) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:1rem;color:#f87171;">' + ex.message + '</td></tr>';
  }
}

// ── PERSIST GAME (rejoin) ──────────────────────────────────────────────────
function saveBoardState() {
  if (gameOver) { sessionStorage.removeItem('vncaro_game'); return; }
  try {
    sessionStorage.setItem('vncaro_game', JSON.stringify({
      BD: BD, FORB: FORB, turn: turn, moveCount: moveCount,
      xFirst: xFirst, oFirst: oFirst, myPiece: myPiece,
      roomCode: currentRoom
    }));
  } catch(e) {}
}

// ── SOUND ──────────────────────────────────────────────────────────────────
function beep() {
  try {
    var a = new (window.AudioContext || window.webkitAudioContext)();
    var o = a.createOscillator(), g = a.createGain();
    o.connect(g); g.connect(a.destination);
    o.frequency.value = 880; g.gain.value = 0.1;
    o.start(); o.stop(a.currentTime + 0.07);
  } catch(e) {}
}

// ── UTILS ──────────────────────────────────────────────────────────────────
function escHtml(str) {
  var d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

// ── INIT ───────────────────────────────────────────────────────────────────
(async function init() {
  var token = API.loadToken();
  if (!token) { showScreen('s-login'); return; }
  try {
    var data = await API.me();
    currentUser = data.user;
    connectSocket(token);
  } catch(e) {
    API.setToken(null);
    showScreen('s-login');
  }
})();
