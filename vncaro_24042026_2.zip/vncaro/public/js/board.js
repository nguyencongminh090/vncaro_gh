// ─── Board ────────────────────────────────────────────────────────────────────

const Board = {
  el: null,
  state: null,   // full game state from server
  myPiece: null, // 'X' or 'O'
  onMove: null,  // callback(row, col)

  init(container) {
    this.el = container;
    this.el.innerHTML = '';
    for (let r = 0; r < 15; r++) {
      for (let c = 0; c < 15; c++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.r = r;
        cell.dataset.c = c;
        cell.addEventListener('click', () => this._handleClick(r, c));
        this.el.appendChild(cell);
      }
    }
  },

  getCell(r, c) {
    return this.el.querySelector(`[data-r="${r}"][data-c="${c}"]`);
  },

  _handleClick(r, c) {
    if (!this.onMove) return;
    if (!this.state) return;
    if (this.state.currentTurn !== this.myPiece) return;
    if (this.state.board[r][c] !== null) return;
    this.onMove(r, c);
  },

  placePiece(r, c, piece) {
    if (this.state) this.state.board[r][c] = piece;
    const cell = this.getCell(r, c);
    if (!cell) return;
    const div = document.createElement('div');
    div.className = `piece ${piece === 'X' ? 'piece-black' : 'piece-white'}`;
    cell.appendChild(div);
    cell.classList.add('no-click');
  },

  highlightWin(cells) {
    cells.forEach(([r, c]) => {
      const cell = this.getCell(r, c);
      if (cell) cell.querySelector('.piece')?.classList.add('winning');
    });
  },

  lock() {
    this.el.querySelectorAll('.cell').forEach(c => c.classList.add('no-click'));
  },

  unlock() {
    this.el.querySelectorAll('.cell:not([data-occupied])').forEach(c => {
      if (!c.querySelector('.piece')) c.classList.remove('no-click');
    });
  },

  reset() {
    this.state = null;
    this.myPiece = null;
    this.onMove = null;
    if (this.el) this.el.innerHTML = '';
  }
};
